# Daily Spend Game (browser-only upload)

This repo is set up so you can **upload via the GitHub web UI** and have an **APK artifact** produced by GitHub Actions, no terminal needed.

## Browser-only steps
1. Create a new repository on GitHub.
2. Click **"uploading an existing file"** and drag the **contents** of this folder (not the outer folder itself) into the page. The `.github/workflows/build-apk.yml` file must be included.
3. Click **Commit changes**.
4. Go to the **Actions** tab → if prompted, click **Enable workflows**.
5. Open the latest run of **Build Debug APK** (triggered by your push) → Download the artifact **DailySpendGame-debug-apk**.
6. Unzip the artifact; install `app-debug.apk` on your Android device (allow "Install unknown apps" on your phone).

This workflow installs Android SDK + Gradle in the runner and builds your APK automatically.
