package com.example.dailyspendgame

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "dailypaygame")

object Keys {
    val NEXT_PAY_DATE = stringPreferencesKey("next_pay_date")
    val REMAINING = longPreferencesKey("remaining_cents")
    val SAVINGS = longPreferencesKey("savings_cents")
    val LOG_JSON = stringPreferencesKey("log_json")
    val LAST_ACTION_JSON = stringPreferencesKey("last_action_json")
}

class GameRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    val state: Flow<GameState> = context.dataStore.data.map { prefs ->
        val next = prefs[Keys.NEXT_PAY_DATE]
        val remaining = prefs[Keys.REMAINING] ?: 0L
        val savings = prefs[Keys.SAVINGS] ?: 0L
        val log = prefs[Keys.LOG_JSON]?.let { json.decodeFromString<List<ExpenseEntry>>(it) } ?: emptyList()
        val last = prefs[Keys.LAST_ACTION_JSON]?.let { json.decodeFromString<LastAction>(it) }
        GameState(next, remaining, savings, log, last)
    }

    suspend fun setInitialState(nextPayIso: String, remainingCents: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.NEXT_PAY_DATE] = nextPayIso
            prefs[Keys.REMAINING] = remainingCents.coerceAtLeast(0L)
            prefs[Keys.LOG_JSON] = json.encodeToString(emptyList<ExpenseEntry>())
            prefs.remove(Keys.LAST_ACTION_JSON)
        }
    }

    suspend fun addExpense(todayIso: String, cents: Long, note: String?) {
        if (cents <= 0) return
        context.dataStore.edit { prefs ->
            val remaining = (prefs[Keys.REMAINING] ?: 0L) - cents
            val list = prefs[Keys.LOG_JSON]?.let { json.decodeFromString<List<ExpenseEntry>>(it) }?.toMutableList()
                ?: mutableListOf()
            val idx = list.indexOfFirst { it.date == todayIso }
            if (idx >= 0) {
                val updated = list[idx].copy(cents = list[idx].cents + cents, note = note ?: list[idx].note)
                list[idx] = updated
            } else list.add(ExpenseEntry(todayIso, cents, note))
            prefs[Keys.REMAINING] = remaining
            prefs[Keys.LOG_JSON] = json.encodeToString(list)
            prefs[Keys.LAST_ACTION_JSON] = json.encodeToString(LastAction.AddedExpense(todayIso, cents))
        }
    }

    suspend fun markNoSpend(todayIso: String) {
        context.dataStore.edit { prefs ->
            val list = prefs[Keys.LOG_JSON]?.let { json.decodeFromString<List<ExpenseEntry>>(it) }?.toMutableList()
                ?: mutableListOf()
            if (list.none { it.date == todayIso }) list.add(ExpenseEntry(todayIso, 0))
            prefs[Keys.LOG_JSON] = json.encodeToString(list)
            prefs[Keys.LAST_ACTION_JSON] = json.encodeToString(LastAction.MarkedNoSpend(todayIso))
        }
    }

    suspend fun paydaySweepAndReset(leftoverCents: Long, nextPayIso: String, newRemainingCents: Long) {
        context.dataStore.edit { prefs ->
            val savings = (prefs[Keys.SAVINGS] ?: 0L) + leftoverCents.coerceAtLeast(0L)
            prefs[Keys.SAVINGS] = savings
            prefs[Keys.NEXT_PAY_DATE] = nextPayIso
            prefs[Keys.REMAINING] = newRemainingCents.coerceAtLeast(0L)
            prefs[Keys.LOG_JSON] = json.encodeToString(emptyList<ExpenseEntry>())
            prefs[Keys.LAST_ACTION_JSON] = json.encodeToString(LastAction.SweptAndReset(leftoverCents))
        }
    }

    suspend fun undoLastAction() {
        context.dataStore.edit { prefs ->
            val lastRaw = prefs[Keys.LAST_ACTION_JSON] ?: return@edit
            val last = json.decodeFromString<LastAction>(lastRaw)
            when (last) {
                is LastAction.AddedExpense -> {
                    val list = prefs[Keys.LOG_JSON]?.let { json.decodeFromString<List<ExpenseEntry>>(it) }?.toMutableList()
                        ?: mutableListOf()
                    val idx = list.indexOfFirst { it.date == last.date }
                    if (idx >= 0) {
                        val entry = list[idx]
                        val newCents = (entry.cents - last.cents).coerceAtLeast(0L)
                        if (newCents == 0L && entry.note == null) list.removeAt(idx) else list[idx] = entry.copy(cents = newCents)
                    }
                    val remaining = (prefs[Keys.REMAINING] ?: 0L) + last.cents
                    prefs[Keys.REMAINING] = remaining
                    prefs[Keys.LOG_JSON] = json.encodeToString(list)
                }
                is LastAction.MarkedNoSpend -> {
                    val list = prefs[Keys.LOG_JSON]?.let { json.decodeFromString<List<ExpenseEntry>>(it) }?.toMutableList()
                        ?: mutableListOf()
                    val idx = list.indexOfFirst { it.date == last.date && it.cents == 0L }
                    if (idx >= 0) list.removeAt(idx)
                    prefs[Keys.LOG_JSON] = json.encodeToString(list)
                }
                is LastAction.SweptAndReset -> {
                    val savings = (prefs[Keys.SAVINGS] ?: 0L) - last.leftover
                    prefs[Keys.SAVINGS] = savings.coerceAtLeast(0L)
                    prefs[Keys.REMAINING] = (prefs[Keys.REMAINING] ?: 0L) + last.leftover
                }
            }
            prefs.remove(Keys.LAST_ACTION_JSON)
        }
    }

    suspend fun wipeAll() { context.dataStore.edit { it.clear() } }
}
