package com.example.dailyspendgame

import kotlinx.serialization.Serializable
import java.time.LocalDate

@Serializable
data class ExpenseEntry(
    val date: String,
    val cents: Long,
    val note: String? = null
)

@Serializable
data class GameState(
    val nextPayDate: String?,
    val remainingCents: Long,
    val savingsBankCents: Long,
    val log: List<ExpenseEntry>,
    val lastAction: LastAction? = null
) {
    companion object {
        fun empty(): GameState = GameState(null, 0L, 0L, emptyList(), null)
    }
}

@Serializable
sealed class LastAction {
    @Serializable
    data class AddedExpense(val date: String, val cents: Long): LastAction()
    @Serializable
    data class MarkedNoSpend(val date: String): LastAction()
    @Serializable
    data class SweptAndReset(val leftover: Long): LastAction()
}

fun String.asLocalDate(): LocalDate = LocalDate.parse(this)
