package com.example.dailyspendgame

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

fun dollarsToCents(d: Double): Long = Math.round(d * 100.0)
fun centsToCurrency(c: Long): String = NumberFormat.getCurrencyInstance(Locale.getDefault()).format(c / 100.0)

fun daysLeftIncludingToday(today: LocalDate, nextPay: LocalDate): Long =
    if (!today.isAfter(nextPay)) ChronoUnit.DAYS.between(today, nextPay) + 1 else 0

fun shareCsv(context: Context, filename: String, csv: String) {
    val file = File(context.cacheDir, filename).apply { writeText(csv) }
    val uri = FileProvider.getUriForFile(context, context.packageName + ".provider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, filename)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, context.getString(R.string.share_title)))
}
