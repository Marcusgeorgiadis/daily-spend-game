package com.example.dailyspendgame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainActivity : ComponentActivity() {

    private lateinit var repo: GameRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = GameRepository(this)

        setContent {
            MaterialTheme {
                val state by repo.state.collectAsState(initial = GameState.empty())
                Surface(Modifier.fillMaxSize()) {
                    if (state.nextPayDate == null) {
                        SetupScreen(onStart = { next, remainingDollars ->
                            lifecycleScope.launch {
                                repo.setInitialState(next.toString(), dollarsToCents(remainingDollars))
                            }
                        })
                    } else {
                        HomeScreen(
                            state = state,
                            onAddExpense = { amountDollars, note ->
                                lifecycleScope.launch {
                                    repo.addExpense(LocalDate.now().toString(), dollarsToCents(amountDollars), note)
                                }
                            },
                            onNoSpend = {
                                lifecycleScope.launch { repo.markNoSpend(LocalDate.now().toString()) }
                            },
                            onReset = { nextPay, newRemaining, leftoverToSavings ->
                                lifecycleScope.launch {
                                    repo.paydaySweepAndReset(leftoverToSavings, nextPay.toString(), dollarsToCents(newRemaining))
                                }
                            },
                            onUndo = { lifecycleScope.launch { repo.undoLastAction() } },
                            onWipeAll = { lifecycleScope.launch { repo.wipeAll() } },
                            onExportCsv = {
                                val csv = buildString {
                                    appendLine("date,spent_cents,spent_dollars,note")
                                    for (e in state.log.sortedBy { it.date }) {
                                        val note = (e.note ?: "").replace('"', '\'')
                                        appendLine("${e.date},${e.cents},${e.cents/100.0},"$note"")
                                    }
                                }
                                shareCsv(this@MainActivity, "daily_spend_log.csv", csv)
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(onStart: (LocalDate, Double) -> Unit) {
    var nextPay by remember { mutableStateOf(LocalDate.now().plusDays(14)) }
    var remaining by remember { mutableStateOf("0") }

    Scaffold(topBar = { TopAppBar(title = { Text("Daily Spend Game — Setup") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Enter what you have left after paying bills, and your next pay date. The app will give you a daily allowance that increases on no-spend days.", style = MaterialTheme.typography.bodyMedium)
            DateRow("Next Pay Date", nextPay) { nextPay = it }
            OutlinedTextField(
                value = remaining,
                onValueChange = { remaining = it.filter { ch -> ch.isDigit() || ch == '.' }.take(12) },
                label = { Text("Leftover Amount ($)") },
                keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { onStart(nextPay, remaining.toDoubleOrNull() ?: 0.0) }, modifier = Modifier.align(Alignment.End)) {
                Text("Start")
            }
        }
    }
}

@Composable
fun DateRow(label: String, date: LocalDate, onChange: (LocalDate) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("$label: $date")
        OutlinedButton(onClick = { onChange(date.minusDays(1)) }) { Text("−1 day") }
        OutlinedButton(onClick = { onChange(date.plusDays(1)) }) { Text("+1 day") }
        OutlinedButton(onClick = { onChange(LocalDate.now()) }) { Text("Today") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: GameState,
    onAddExpense: (Double, String?) -> Unit,
    onNoSpend: () -> Unit,
    onReset: (LocalDate, Double, Long) -> Unit,
    onUndo: () -> Unit,
    onWipeAll: () -> Unit,
    onExportCsv: () -> Unit
) {
    val today = LocalDate.now()
    val nextPay = state.nextPayDate!!.asLocalDate()
    val daysLeft = daysLeftIncludingToday(today, nextPay)

    if (!today.isBefore(nextPay)) {
        PaydayScreen(leftover = state.remainingCents, onReset = onReset, savingsBank = state.savingsBankCents)
        return
    }

    val allowedTodayCents = if (daysLeft > 0) {
        kotlin.math.ceil(state.remainingCents.coerceAtLeast(0L).toDouble() / daysLeft.toDouble()).toLong()
    } else 0L
    val spentToday = state.log.find { it.date == today.toString() }?.cents ?: 0L
    val stillAvailableToday = (allowedTodayCents - spentToday).coerceAtLeast(0L)

    var spendInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Daily Spend Game") },
                actions = { TextButton(onClick = onExportCsv) { Text("Export CSV") } }
            )
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Period Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Next payday: $nextPay")
                        Text("Days left (incl. today): $daysLeft")
                        Text("Remaining: ${centsToCurrency(state.remainingCents)}", fontWeight = FontWeight.SemiBold)
                        Text("Savings bank: ${centsToCurrency(state.savingsBankCents)}")
                        Text("Today's allowance: ${centsToCurrency(allowedTodayCents)}")
                        val streak = state.log.sortedByDescending { it.date }.takeWhile { it.cents == 0L }.size
                        if (streak > 0) Text("No-spend streak: $streak day(s)")
                        if (spentToday > 0) Text("Spent today: ${centsToCurrency(spentToday)}")
                        Text("Still available today: ${centsToCurrency(stillAvailableToday)}")
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Add expense", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = spendInput,
                            onValueChange = { spendInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Amount ($)") },
                            keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            label = { Text("Note (optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (spendInput.isNotEmpty()) {
                            val overspend = dollarsToCents(spendInput.toDoubleOrNull() ?: 0.0) > stillAvailableToday
                            if (overspend) Text("Warning: This exceeds today's allowance.", color = MaterialTheme.colorScheme.error)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val amt = spendInput.toDoubleOrNull() ?: 0.0
                                if (amt > 0.0) onAddExpense(amt, noteInput.ifBlank { null })
                                spendInput = ""; noteInput = ""
                            }) { Text("Add") }
                            OutlinedButton(onClick = onNoSpend) { Text("No-spend day") }
                            OutlinedButton(onClick = onUndo) { Text("Undo") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Quick add:")
                            listOf(1.0, 5.0, 10.0).forEach { amt ->
                                AssistChip(
                                    onClick = { onAddExpense(amt, "Quick add") },
                                    label = { Text("$" + "%.0f".format(amt)) }
                                )
                            }
                        }
                    }
                }
            }
            if (state.log.isNotEmpty()) {
                item { Text("Recent days", style = MaterialTheme.typography.titleMedium) }
                items(state.log.sortedByDescending { it.date }.take(20)) { e ->
                    ListItem(
                        headlineContent = { Text(e.date) },
                        supportingContent = { Text(e.note ?: "") },
                        trailingContent = { Text(centsToCurrency(e.cents)) }
                    )
                    Divider()
                }
            }
            item { OutlinedButton(onClick = onWipeAll) { Text("Wipe All Data (reset app)") } }
        }
    }
}

@Composable
fun PaydayScreen(leftover: Long, onReset: (LocalDate, Double, Long) -> Unit, savingsBank: Long) {
    var nextPay by remember { mutableStateOf(LocalDate.now().plusDays(14)) }
    var newRemaining by remember { mutableStateOf("0") }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Payday! 🎉", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Leftover from the last period will be swept to Savings.")
        Text("Leftover: ${centsToCurrency(leftover)}")
        Text("Current Savings: ${centsToCurrency(savingsBank)}")
        DateRow("Next Pay Date", nextPay) { nextPay = it }
        OutlinedTextField(
            value = newRemaining,
            onValueChange = { newRemaining = it.filter { ch -> ch.isDigit() || ch == '.' } },
            label = { Text("New leftover after bills ($)") },
            keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { onReset(nextPay, newRemaining.toDoubleOrNull() ?: 0.0, leftover) }, modifier = Modifier.align(Alignment.End)) {
            Text("Sweep & Start New Cycle")
        }
    }
}
